import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-cart',
  templateUrl: './add-cart.component.html',
  styleUrls: ['./add-cart.component.css']
})
export class AddCartComponent implements OnInit {

  constructor() { }

  feature = [0];

  ngOnInit(): void {
  }

  addFeatures(i){
    this.feature.push(i)
  }

}
