import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  checked = false;
	indeterminate = false;
	labelPosition: 'before' | 'after' = 'after';
	disabled = false;
	tableData
	backUpTableData
	showLoader
	reqData
	getData
	datamodel
	length
	timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone
	filterValue
	responseData = []
  displayedColumns : string[] = ['position', 'content', 'featureTitle', 'feature', 'Action']
  dataSource:any
  element_id
	allReplacement = 54321
	data = []
	selectedUsers = []
	selection
	filter_by
	exam_id
	exam_name
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  constructor() { }

  ngOnInit(): void {
    this.reqData = {}
		this.reqData.offset = 0
		this.reqData.limit = 10
		this.dataSource = new MatTableDataSource(this.responseData);
		this.dataSource.paginator = this.paginator;
		this.dataSource.sort = this.sort;
		this.datamodel = {}
  }

  ngAfterViewInit() {
		this.dataSource.paginator = this.paginator
  }
  
  getPageSizeOptions() {
		return [5,10, 20, 30];
  }
  
  paginationOptionChange(evt) {
		console.log(evt)
		this.reqData.offset = (evt.pageIndex * evt.pageSize).toString()
		this.reqData.limit = evt.pageSize
		console.log(this.reqData)
		// this.service.getFaqAllList(this.reqData.limit, this.reqData.offset).subscribe(data => {
		// 	console.log(data)
		// 	if (data) {
		// 		this.responseData = data.data.rows
		// 		this.length = data.data.count
		// 		this.dataSource = new MatTableDataSource(data.data);
		// 		this.dataSource.sort = this.sort;
		// 		console.log(this.dataSource)
		// 		if (this.filterValue) {
		// 			this.dataSource.filter = this.filterValue
		// 		}
		// 	}
		// }, err => {
		// 	console.log(err)
		// 	if (err.status >= 400) {
		// 		// this.toastr.error('Internal Error', 'Error')
		// 	} else {
		// 		// this.toastr.error('Internet Connection Error', 'Error')
		// 		console.log('Internet Connection Error')
		// 	}
		// })
    }

}
