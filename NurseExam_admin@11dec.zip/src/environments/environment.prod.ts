export const environment = {
  production: true,
  endPoint: "https://developers.promaticstechnologies.com:3003/",
  //endPoint: "http://localhost:3003/"
  img_path: 'https://developers.promaticstechnologies.com/NurseExam_apis/public/',
  profile_img:'https://developers.promaticstechnologies.com/NurseExam_apis/public/AdminProfileImage/'
};
